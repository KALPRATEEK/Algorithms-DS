import org.junit.jupiter.api.Test;

import java.io.IOException;

class HuffmanTest {

    @Test
    void testHuffmanEncodingAndDecoding() throws IOException {
        // Prepare test data

    }
}
