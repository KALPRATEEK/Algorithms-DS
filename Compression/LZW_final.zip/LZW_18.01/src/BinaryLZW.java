import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
// complete working model based on Hashmap
//optional
public class BinaryLZW {

    private static final int MAX_DICT_SIZE = 4096;
    private static final int BITS_PER_CODE = 12;

    public static List<Integer> encode(byte[] data) {
        int dictSize = 1028;
        Map<String, Integer> dictionary = new HashMap<>();
        for (int i = 0; i < dictSize; i++) {
            dictionary.put(String.valueOf((char) i), i);
        }

        StringBuilder foundChars = new StringBuilder();
        List<Integer> result = new ArrayList<>();
        for (byte b : data) {
            int currentByte = b & 0xFF;  // Convert byte to unsigned int
            String charsToAdd = foundChars.toString() + (char) currentByte;
            if (dictionary.containsKey(charsToAdd)) {
                foundChars = new StringBuilder(charsToAdd);
            } else {
                result.add(dictionary.get(foundChars.toString()));

                if (dictSize < MAX_DICT_SIZE) {
                    dictionary.put(charsToAdd, dictSize++);
                }

                foundChars = new StringBuilder(String.valueOf((char) currentByte));
            }
        }
        if (foundChars.length() > 0) {
            result.add(dictionary.get(foundChars.toString()));
        }
        return result;
    }

    public static byte[] decode(List<Integer> encodedText) {
        int dictSize = 1028;
        Map<Integer, String> dictionary = new HashMap<>();
        for (int i = 0; i < dictSize; i++) {
            dictionary.put(i, String.valueOf((char) i));
        }

        ByteArrayOutputStream result = new ByteArrayOutputStream();
        int prevCode = encodedText.remove(0);
        result.write(prevCode);

        for (int code : encodedText) {
            String entry;
            if (dictionary.containsKey(code)) {
                entry = dictionary.get(code);
            } else if (code == dictSize) {
                entry = dictionary.get(prevCode) + dictionary.get(prevCode).charAt(0);
            } else {
                throw new IllegalArgumentException("Invalid LZW code: " + code);
            }

            for (char c : entry.toCharArray()) {
                result.write(c);
            }

            if (dictSize < MAX_DICT_SIZE) {
                dictionary.put(dictSize++, dictionary.get(prevCode) + entry.charAt(0));
            }

            prevCode = code;
        }
        return result.toByteArray();
    }

    public static void compressFile(String inputFileName, String compressedFileName) {
        try (FileInputStream fis = new FileInputStream(inputFileName);
             MyBitOutputStream compressedOutputStream = new MyBitOutputStream(new FileOutputStream(compressedFileName))) {

            byte[] data = fis.readAllBytes();
            List<Integer> encodedText = encode(data);
            writeBits(compressedOutputStream, encodedText);

            System.out.println("File compressed successfully.");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void decompressFile(String compressedFileName, String outputFileName) {
        try (MyBitInputStream compressedInputStream = new MyBitInputStream(new FileInputStream(compressedFileName));
             FileOutputStream fos = new FileOutputStream(outputFileName)) {

            List<Integer> encodedText = readBits(compressedInputStream);
            byte[] decodedText = decode(encodedText);
            fos.write(decodedText);

            System.out.println("File decompressed successfully.");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void writeBits(MyBitOutputStream outputStream, List<Integer> encodedText) throws IOException {
        for (int code : encodedText) {
            outputStream.writeBits(code, BITS_PER_CODE);
        }
    }

    private static List<Integer> readBits(MyBitInputStream inputStream) throws IOException {
        List<Integer> encodedText = new ArrayList<>();
        int bits;
        while ((bits = inputStream.readBits(BITS_PER_CODE)) != -1) {
            encodedText.add(bits);
        }
        return encodedText;
    }

    public static void main(String[] args) {
        String inputFileName = "pdf.pdf";
        String compressedFileName = "compressed_binary.lzw";
        String decompressedFileName = "decompressed_binary.pdf";

        // Compress the file
        compressFile(inputFileName, compressedFileName);

        // Decompress the file
        decompressFile(compressedFileName, decompressedFileName);
    }
}
