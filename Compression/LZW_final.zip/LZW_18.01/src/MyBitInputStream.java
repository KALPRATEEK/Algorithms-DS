import java.io.IOException;
import java.io.InputStream;

public class MyBitInputStream implements AutoCloseable {

    private InputStream input;
    private int currentByte;
    private int numBitsFilled;

    public MyBitInputStream(InputStream in) {
        if (in == null) {
            throw new NullPointerException("Argument is null");
        }
        input = in;
        currentByte = 0;
        numBitsFilled = 0;
    }

    public int readBits(int numBits) throws IOException {
        if (numBits < 0 || numBits > 32) {
            throw new IllegalArgumentException("Number of bits must be between 0 and 32");
        }

        int result = 0;
        for (int i = 0; i < numBits; i++) {
            if (numBitsFilled == 0) {
                currentByte = input.read();
                if (currentByte == -1) {
                    // End of stream reached
                    return -1;
                }
                numBitsFilled = 8;
            }

            int mask = 1 << (numBitsFilled - 1);
            result |= ((currentByte & mask) >> (numBitsFilled - 1)) << (numBits - 1 - i);
            numBitsFilled--;
        }

        return result;
    }

    @Override
    public void close() throws IOException {
        input.close();
    }
}
