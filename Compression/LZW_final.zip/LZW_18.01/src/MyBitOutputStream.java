import java.io.Closeable;
import java.io.IOException;
import java.io.OutputStream;

public class MyBitOutputStream implements Closeable {

    private OutputStream outputStream;
    private int currentByte;
    private int numBitsFilled;
    private int totalBitsWritten; // Added field to track
    public MyBitOutputStream(OutputStream outputStream) {
        this.outputStream = outputStream;
        this.currentByte = 0;
        this.numBitsFilled = 0;
        this.totalBitsWritten = 0;
    }

    public void writeBits(int bits, int numBits) throws IOException {
        if (numBits < 0 || numBits > 32) {
            throw new IllegalArgumentException("Number of bits must be between 0 and 32");
        }

        for (int i = numBits - 1; i >= 0; i--) {
            int bit = (bits >>> i) & 1;
            writeBit(bit);
        }
    }

    private void writeBit(int bit) throws IOException {
        if (!(bit == 0 || bit == 1)) {
            throw new IllegalArgumentException("Argument must be 0 or 1");
        }

        currentByte = (currentByte << 1) | bit;
        numBitsFilled++;

        if (numBitsFilled == 8) {
            outputStream.write(currentByte);
            currentByte = 0;
            numBitsFilled = 0;

        }
        totalBitsWritten++;
    }

    public void close() throws IOException {
        while (numBitsFilled != 0) {
            writeBit(0);
        }
        outputStream.close();
    }
    public int getTotalBitsWritten() {
        return totalBitsWritten;
    }
}
