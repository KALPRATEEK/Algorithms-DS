import java.io.*;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
// complete working model based of Binary search tree
public class BSTLZW {

    private static final int MAX_DICT_SIZE = 4096;
    private static final int BITS_PER_CODE = 12;

    public static List<Integer> encode(byte[] data) {
        int dictSize = 1028;
        BSTree<String, Integer> dictionary = new BSTree<>();

        // Initialize the dictionary with single-character entries
        for (int i = 0; i < dictSize; i++) {
            dictionary.insert(String.valueOf((char) i), i);
        }

        StringBuilder foundChars = new StringBuilder();
        List<Integer> result = new ArrayList<>();
        List<Integer> encodedLengths = new ArrayList<>();  // New list to store lengths

        for (byte b : data) {
            int currentByte = b & 0xFF;  // Convert byte to unsigned int
            String charsToAdd = foundChars.toString() + (char) currentByte;

            if (dictionary.contains(charsToAdd)) {
                foundChars = new StringBuilder(charsToAdd);
            } else {
                // Add the code for the foundChars to the result
                result.add(dictionary.get(foundChars.toString()));

                // Add the length of foundChars to the encodedLengths list
                encodedLengths.add(foundChars.length());

                if (dictSize < MAX_DICT_SIZE) {
                    // Add charsToAdd to the dictionary with the next available code
                    dictionary.insert(charsToAdd, dictSize++);
                }

                foundChars = new StringBuilder(String.valueOf((char) currentByte));
            }
        }

        // Add the code and length for the remaining foundChars to the result
        if (foundChars.length() > 0) {
            result.add(dictionary.get(foundChars.toString()));
            encodedLengths.add(foundChars.length());
        }

        // Store the encoded lengths in a global variable or return them if needed for further calculations
        // globalEncodedLengths = encodedLengths;

        return result;
    }


    public static byte[] decode(List<Integer> encodedText) {
        int dictSize = 1028;
        BSTree<Integer, String> dictionary = new BSTree<>();

        // Initialize the dictionary with single-character entries
        for (int i = 0; i < dictSize; i++) {
            dictionary.insert(i, String.valueOf((char) i));
        }

        ByteArrayOutputStream result = new ByteArrayOutputStream();
        int prevCode = encodedText.remove(0);
        result.write(prevCode);

        for (int code : encodedText) {
            String entry;
            if (dictionary.contains(code)) {
                entry = dictionary.get(code);
            } else if (code == dictSize) {
                entry = dictionary.get(prevCode) + dictionary.get(prevCode).charAt(0);
            } else {
                throw new IllegalArgumentException("Invalid LZW code: " + code);
            }

            for (char c : entry.toCharArray()) {
                result.write(c);
            }

            if (dictSize < MAX_DICT_SIZE) {
                // Add the previous code + entry[0] to the dictionary with the next available code
                dictionary.insert(dictSize++, dictionary.get(prevCode) + entry.charAt(0));
            }

            prevCode = code;
        }

        return result.toByteArray();
    }
    public static void compressFile(String inputFileName, String compressedFileName) {
        try (FileInputStream fis = new FileInputStream(inputFileName);
             MyBitOutputStream compressedOutputStream = new MyBitOutputStream(new FileOutputStream(compressedFileName))) {

            byte[] data = fis.readAllBytes();
            List<Integer> encodedText = encode(data);



            // Calculate average encoded string length
            int totalStringLength = 0;
            for (int length : encodedText) {
                totalStringLength += length;
            }
            double averageEncodedStringLength = (double) totalStringLength / encodedText.size();
            System.out.println("Average Encoded String Length: " + averageEncodedStringLength + " characters");

            writeBits(compressedOutputStream, encodedText);

            // Compressing rate calculation
            long originalSize = fis.getChannel().size();
            long compressedSize = new File(compressedFileName).length();
            double compressionRate = 1 - ((double) compressedSize / originalSize);
            DecimalFormat df = new DecimalFormat("#.##");
            System.out.println("Compression Rate: " + df.format(compressionRate * 100) + "%");

            System.out.println("File compressed successfully.");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void decompressFile(String compressedFileName, String outputFileName) {
        try (MyBitInputStream compressedInputStream = new MyBitInputStream(new FileInputStream(compressedFileName));
             FileOutputStream fos = new FileOutputStream(outputFileName)) {

            List<Integer> encodedText = readBits(compressedInputStream);
            byte[] decodedText = decode(encodedText);
            fos.write(decodedText);

            System.out.println("File decompressed successfully.");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void writeBits(MyBitOutputStream outputStream, List<Integer> encodedText) throws IOException {
        for (int code : encodedText) {
            outputStream.writeBits(code, BITS_PER_CODE);
        }
    }

    private static List<Integer> readBits(MyBitInputStream inputStream) throws IOException {
        List<Integer> encodedText = new ArrayList<>();
        int bits;
        while ((bits = inputStream.readBits(BITS_PER_CODE)) != -1) {
            encodedText.add(bits);
        }
        return encodedText;
    }

    public static void main(String[] args) {

        String inputFileName = "Excel.xlsx";
        String compressedFileName = "compressed_excel.lzw";
        String decompressedFileName = "decompressed_excel.xlsx";
        // Compress the file
        compressFile(inputFileName, compressedFileName);

        // Decompress the file
        decompressFile(compressedFileName, decompressedFileName);

        System.out.println("encode and decoded Excel file sucessfully!");

        inputFileName = "test.txt";
        compressedFileName = "Compressed_text.lzw";
        decompressedFileName = "decompressed_text.txt";

        compressFile(inputFileName, compressedFileName);

        // Decompress the file
        decompressFile(compressedFileName, decompressedFileName);
        System.out.println("encode and decoded text file sucessfully!");

        inputFileName = "pdf.pdf";
        compressedFileName = "Compressed_pdf.lzw";
        decompressedFileName = "decompressed_pdf.pdf";

        compressFile(inputFileName, compressedFileName);

        // Decompress the file
        decompressFile(compressedFileName, decompressedFileName);
        System.out.println("encode and decoded pdf file sucessfully!");





    }


}
